# Sito delle classi

Ogni classe vede l'indice della sua programmazione. Unità, lezioni e attività compaiono man mano che le attivi.
I materiali non sono copiati qui: si aprono dal sito «Scuola facile» (didattica.amnesiacreativa.it),
che resta l'archivio di tutto. Il catalogo è sempre `materiali.js` di quel sito.

## File
- `index.html`: scelta della classe. Ai ragazzi si può dare questa pagina o direttamente `classe.html?c=classe-1`.
- `classe.html`: la programmazione della classe.
- `docente.html`: la tua pagina per comporre e attivare le programmazioni. Non è collegata da nessuna parte.
- `config.js`: nomi e anno delle classi, indirizzo dell'archivio.
- `percorsi/classe-N.js`: la programmazione di ogni classe (lo crea `docente.html`).

## Preparare la programmazione di una classe
1. Apri `docente.html` e scegli la classe.
2. **+ Unità da un modulo**: scegli un modulo del catalogo. Entra con tutte le sue lezioni e attività, **nascoste**.
3. Togli (✕) quello che non fate, riordina (↑ ↓), aggiungi singole lezioni o attività di altri moduli,
   compiti o note («+ Compito, nota o link»).
4. In ogni lezione, **Parti da mostrare**: togli la spunta alle parti che la classe non deve vedere.

## Lavoro di tutti i giorni
1. In `docente.html` spunta **visibile** per l'unità e per ciò che avete fatto,
   oppure metti una data in **dal**: la voce compare da sola quel giorno.
2. **Anteprima** per vedere cosa vedranno i ragazzi.
3. **Scarica il file da pubblicare** → in GitHub Desktop (o su github.com) metti `classe-N.js`
   nella cartella `percorsi/` al posto del vecchio → Commit → Push.
   Dopo circa un minuto il sito è aggiornato.

Le modifiche restano salvate nel browser finché non le pubblichi.

## Che cosa vedono i ragazzi
- L'indice di tutte le unità: quelle non ancora attive hanno il lucchetto («in arrivo»).
- L'ultima unità attiva è «in corso» e si apre da sola; le precedenti sono «svolte».
- Le voci aperte negli ultimi 7 giorni hanno l'etichetta «nuovo».
- Una lezione aperta da qui mostra solo le parti scelte. Il menu del sito è nascosto e c'è
  il pulsante «← Torna alla classe». Così i ragazzi non si perdono nel resto del sito.

Ciò che non è attivo è nascosto, non segreto: il sito Scuola facile resta pubblico.

## Pubblicazione (una volta sola)
1. In GitHub Desktop: File → Add local repository → questa cartella `classi` → «create a repository» → Publish,
   **togliendo** la spunta «Keep this code private».
2. Su github.com, nel repository: Settings → Pages → Deploy from a branch → `main` / `(root)` → Save.
3. L'indirizzo sarà `https://guzzettg-cell.github.io/classi/`. Volendo si può usare un sottodominio,
   per esempio `classi.amnesiacreativa.it`, come per il sito principale.

Sul computer basta aprire `classe.html` o `docente.html` con doppio clic: i materiali si leggono
dalla cartella `didattica` accanto a questa, quindi si vedono subito anche le modifiche non ancora pubblicate.

## Che cosa è cambiato nel sito Scuola facile
- `assets/barra.js`: in fondo c'è un blocco nuovo (sezione 3) che legge `?parti=` e `&torna=`
  dall'indirizzo. Senza queste aggiunte le pagine sono quelle di sempre.
- `strumenti/crea-indice-parti.py` scrive `assets/indice-parti.js`, cioè l'elenco delle parti di ogni pagina.
  Lo fa da solo l'azione «Indice della ricerca», insieme all'indice di ricerca.
- Le parti sono le `section class="parte"` delle lezioni (con i nomi dell'indice laterale) oppure,
  nelle altre pagine, le `section` principali con un titolo. Le presentazioni a diapositive restano intere.
