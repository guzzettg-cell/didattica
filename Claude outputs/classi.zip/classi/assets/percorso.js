// Regole comuni a classe.html e docente.html
window.Percorso = (function () {
  function oggi() {
    var d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }
  // Una parte è aperta se è spuntata "attiva" oppure se la sua data "dal" è arrivata
  function aperta(x) {
    return !!x.attiva || (!!x.dal && x.dal <= oggi());
  }
  // Data da cui la voce è aperta (per l'etichetta "nuovo")
  function dataApertura(x) {
    if (x.dal && x.dal <= oggi()) return x.dal;
    return x.attivataIl || "";
  }
  function giorniDa(data) {
    if (!data) return Infinity;
    return Math.floor((new Date(oggi()) - new Date(data)) / 86400000);
  }
  // Indirizzo di una voce. "torna" = indirizzo della pagina della classe, per il pulsante «← Torna alla classe»
  function link(base, v, torna) {
    if (v.url) return v.url;
    if (!v.file) return "";
    var p = [];
    if (v.parti && v.parti.length) p.push("parti=" + v.parti.map(encodeURIComponent).join(","));
    if (torna) p.push("torna=" + encodeURIComponent(torna));
    return base + v.file + (p.length ? "?" + p.join("&") : "");
  }
  // Carica un file .js con <script> (funziona anche aprendo i file dal computer)
  function caricaScript(src) {
    return new Promise(function (ok, ko) {
      var s = document.createElement("script");
      s.src = src;
      s.onload = function () { s.remove(); ok(); };
      s.onerror = function () { s.remove(); ko(new Error("Non trovo " + src)); };
      document.head.appendChild(s);
    });
  }
  var icone = { Lezione: "📖", Modulo: "📚", Esercizi: "✏️", Scheda: "🗒️", Ripasso: "🔁", Verifica: "📝", Presentazione: "🖥️",
    Video: "🎬", Lettura: "📕", Questionario: "❓", Gioco: "🎲", Laboratorio: "🔬", Mappa: "🗺️", Compito: "🏠", Attività: "🧩", Link: "🔗" };
  function icona(tipo) { return icone[tipo] || "📄"; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  return { oggi: oggi, aperta: aperta, dataApertura: dataApertura, giorniDa: giorniDa, link: link, caricaScript: caricaScript, icona: icona, esc: esc };
})();
