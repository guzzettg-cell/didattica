// Impostazioni del sito delle classi. Qui si cambiano i nomi delle classi.
window.CONFIG = {
  // Indirizzo del sito dei materiali (l'archivio), con la barra finale.
  // Sul computer (aprendo i file con doppio clic) usa la cartella "didattica" accanto a questa;
  // online usa il sito pubblicato.
  archivio: location.protocol === "file:" ? "../didattica/" : "https://didattica.amnesiacreativa.it/",

  titolo: "Le nostre lezioni",

  // Una riga per classe.
  //   id:   nome del file in percorsi/ (senza .js), senza spazi
  //   nome: come appare ai ragazzi
  //   anno: prima | seconda | terza  (serve a proporre subito i materiali giusti dal catalogo)
  classi: [
    { id: "classe-1", nome: "Classe 1", anno: "prima" },
    { id: "classe-2", nome: "Classe 2", anno: "seconda" },
    { id: "classe-3", nome: "Classe 3", anno: "seconda" },
    { id: "classe-4", nome: "Classe 4", anno: "terza" }
  ],

  // Per quanti giorni una voce appena attivata mostra l'etichetta «nuovo»
  giorniNovita: 7
};
