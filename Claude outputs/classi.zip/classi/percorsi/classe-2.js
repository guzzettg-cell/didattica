// Programmazione della classe — da compilare con docente.html
window.PERCORSO = {
 "classe": "classe-2",
 "unita": []
};
