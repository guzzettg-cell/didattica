# Archivio dei materiali

Il sito con **tutti** i materiali. Il sito delle classi richiama i materiali da qui.

## Come aggiungere un materiale
1. Metti il file HTML in `materiali/<materia>/` (es. `materiali/storia/seicento-testi.html`).
2. Nella parte `<head>` del file compila le schede:
   ```html
   <meta name="materia" content="Storia">
   <meta name="classi" content="2">          <!-- anni: 2 oppure 2,3 -->
   <meta name="modulo" content="M2 Il Seicento">
   <meta name="tipo" content="Lezione">       <!-- Lezione, Esercizi, Verifica, Video, Attività -->
   <meta name="descrizione" content="Una riga che spiega il materiale">
   <script src="../../assets/parti.js"></script>
   ```
3. Ogni parte che vuoi poter mostrare o nascondere va racchiusa così:
   ```html
   <section data-parte="approfondimento" data-titolo="Approfondimento"> … </section>
   ```
4. Carica il file su GitHub. Il catalogo (`catalogo.js`) si aggiorna da solo in circa un minuto (scheda *Actions*).
   Se lavori sul computer: `python3 strumenti/aggiorna_catalogo.py`.

## Mostrare solo alcune parti
`lezione.html?parti=dove,chi` mostra solo le parti `dove` e `chi`. Il sito delle classi crea questi link da solo.

## Pubblicazione (una volta sola)
Repository **pubblico** di nome `archivio` → *Settings → Pages → Deploy from a branch → main / (root)*.
L'indirizzo sarà `https://NOMEUTENTE.github.io/archivio/`.
Poi *Settings → Actions → General → Workflow permissions → Read and write*, così l'azione può salvare il catalogo.

> I file in `materiali/` sono di esempio: cancellali quando metti i tuoi.
