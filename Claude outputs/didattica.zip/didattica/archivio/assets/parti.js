/*
  parti.js — mostra solo le parti di una lezione scelte per la classe.

  Nella lezione, ogni parte selezionabile è un elemento con:
      data-parte="id-breve"  data-titolo="Titolo leggibile"
  Esempio:
      <section data-parte="approfondimento" data-titolo="Approfondimento"> ... </section>

  Nell'indirizzo della pagina:
      lezione.html                       → mostra tutto
      lezione.html?parti=dove,quando     → mostra solo quelle parti
  Le parti senza data-parte (titolo, piè di pagina...) restano sempre visibili.
*/
(function () {
  function applica() {
    var q = new URLSearchParams(location.search);
    var scelta = q.get("parti");
    if (!scelta) return;
    var ammesse = scelta.split(",").map(function (s) { return s.trim(); }).filter(Boolean);
    var nascoste = 0;
    document.querySelectorAll("[data-parte]").forEach(function (el) {
      if (ammesse.indexOf(el.getAttribute("data-parte")) === -1) {
        el.hidden = true;
        el.style.display = "none";
        nascoste++;
      }
    });
    // Nasconde anche le voci di un eventuale indice interno che puntano a parti nascoste
    document.querySelectorAll("a[href^='#']").forEach(function (a) {
      var t = document.getElementById(a.getAttribute("href").slice(1));
      if (t && t.closest("[data-parte]") && t.closest("[data-parte]").hidden) {
        var li = a.closest("li");
        (li || a).style.display = "none";
      }
    });
    document.documentElement.setAttribute("data-parti-filtrate", nascoste ? "si" : "no");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", applica);
  else applica();
})();
