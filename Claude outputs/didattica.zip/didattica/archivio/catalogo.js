// File generato automaticamente da strumenti/aggiorna_catalogo.py — non modificarlo a mano
window.CATALOGO = {
 "aggiornato": "2026-11-24",
 "materiali": [
  {
   "id": "geografia/clima-fasce-climatiche",
   "file": "materiali/geografia/clima-fasce-climatiche.html",
   "titolo": "Le fasce climatiche",
   "materia": "Geografia",
   "classi": [
    "3"
   ],
   "modulo": "Il clima",
   "tipo": "Lezione",
   "descrizione": "ESEMPIO — Le fasce climatiche della Terra, con video e attività.",
   "parti": [
    {
     "id": "testo",
     "titolo": "Testo"
    },
    {
     "id": "video",
     "titolo": "Video"
    },
    {
     "id": "attivita",
     "titolo": "Attività sul libro"
    }
   ]
  },
  {
   "id": "storia/seicento-idea-principale",
   "file": "materiali/storia/seicento-idea-principale.html",
   "titolo": "Il Seicento — Idea principale",
   "materia": "Storia",
   "classi": [
    "2"
   ],
   "modulo": "M2 Il Seicento",
   "tipo": "Lezione",
   "descrizione": "ESEMPIO — Dove, quando e chi: il Seicento in breve.",
   "parti": [
    {
     "id": "dove",
     "titolo": "Dove? Che cosa?"
    },
    {
     "id": "quando",
     "titolo": "Quando"
    },
    {
     "id": "chi",
     "titolo": "Chi"
    },
    {
     "id": "approfondimento",
     "titolo": "Approfondimento"
    }
   ]
  },
  {
   "id": "storia/seicento-rivoluzione-scientifica",
   "file": "materiali/storia/seicento-rivoluzione-scientifica.html",
   "titolo": "La rivoluzione scientifica — Esercizi",
   "materia": "Storia",
   "classi": [
    "2"
   ],
   "modulo": "M2 Il Seicento",
   "tipo": "Esercizi",
   "descrizione": "ESEMPIO — Esercizi su Galileo e il metodo sperimentale, in due livelli.",
   "parti": [
    {
     "id": "base",
     "titolo": "Esercizi di base"
    },
    {
     "id": "avanzati",
     "titolo": "Esercizi avanzati"
    }
   ]
  }
 ]
};
