#!/usr/bin/env python3
"""
Aggiorna catalogo.js leggendo tutti i file HTML in materiali/.

Per ogni file legge:
  <title>                         → titolo
  <meta name="materia">           → materia (es. Storia)
  <meta name="classi">            → anni di corso, separati da virgola (es. 2 oppure 2,3)
  <meta name="modulo">            → modulo o unità
  <meta name="tipo">              → Lezione, Esercizi, Verifica, Video...
  <meta name="descrizione">       → una riga di descrizione
  elementi con data-parte e data-titolo → parti selezionabili

Uso (dalla cartella principale dell'archivio):
    python3 strumenti/aggiorna_catalogo.py
Su GitHub lo fa da solo l'azione in .github/workflows/catalogo.yml a ogni modifica.
"""
import json
import pathlib
import datetime
from html.parser import HTMLParser

RADICE = pathlib.Path(__file__).resolve().parent.parent
MATERIALI = RADICE / "materiali"
USCITA = RADICE / "catalogo.js"


class Lettore(HTMLParser):
    def __init__(self):
        super().__init__()
        self.meta = {}
        self.titolo = ""
        self._in_title = False
        self.parti = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "title":
            self._in_title = True
        elif tag == "meta" and a.get("name"):
            self.meta[a["name"].strip().lower()] = (a.get("content") or "").strip()
        if "data-parte" in a:
            pid = (a.get("data-parte") or "").strip()
            if pid and pid not in [p["id"] for p in self.parti]:
                self.parti.append({"id": pid, "titolo": (a.get("data-titolo") or pid).strip()})

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title:
            self.titolo += data


def main():
    voci = []
    for f in sorted(MATERIALI.rglob("*.html")):
        l = Lettore()
        l.feed(f.read_text(encoding="utf-8", errors="replace"))
        rel = f.relative_to(RADICE).as_posix()
        voci.append({
            "id": f.relative_to(MATERIALI).with_suffix("").as_posix(),
            "file": rel,
            "titolo": l.titolo.strip() or f.stem.replace("-", " "),
            "materia": l.meta.get("materia", "Altro"),
            "classi": [c.strip() for c in l.meta.get("classi", "").split(",") if c.strip()],
            "modulo": l.meta.get("modulo", ""),
            "tipo": l.meta.get("tipo", ""),
            "descrizione": l.meta.get("descrizione", ""),
            "parti": l.parti,
        })
    dati = {"aggiornato": datetime.date.today().isoformat(), "materiali": voci}
    USCITA.write_text(
        "// File generato automaticamente da strumenti/aggiorna_catalogo.py — non modificarlo a mano\n"
        "window.CATALOGO = " + json.dumps(dati, ensure_ascii=False, indent=1) + ";\n",
        encoding="utf-8",
    )
    print(f"Catalogo aggiornato: {len(voci)} materiali → {USCITA.name}")


if __name__ == "__main__":
    main()
