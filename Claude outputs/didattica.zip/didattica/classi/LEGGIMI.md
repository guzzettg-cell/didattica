# Sito delle classi

Ogni classe vede l'indice della sua programmazione. Le unità e i materiali compaiono man mano che li attivi.

## File
- `index.html`: scelta della classe (pagina da dare ai ragazzi, o `classe.html?c=classe-1` per una classe sola)
- `classe.html`: la programmazione della classe
- `docente.html`: la tua pagina per comporre e attivare i percorsi (non è collegata da nessuna parte)
- `config.js`: nomi delle classi e indirizzo dell'archivio
- `percorsi/classe-N.js`: il percorso di ogni classe (lo crea `docente.html`)

## Lavoro di tutti i giorni
1. Apri `docente.html` e scegli la classe.
2. Aggiungi materiali dall'archivio, scegli le parti, spunta **visibile** per ciò che avete fatto.
   In alternativa metti una data in **dal**: la voce compare da sola quel giorno.
3. **Anteprima** per vedere cosa vedranno i ragazzi.
4. **Scarica il file da pubblicare** → su GitHub apri la cartella `percorsi/` → *Add file → Upload files* → trascina `classe-N.js` → *Commit*.
   Dopo circa un minuto il sito è aggiornato.

Le modifiche restano salvate nel browser finché non le pubblichi.

## Regole di visibilità
- Un'unità o una voce è visibile se è spuntata **visibile** oppure se la data **dal** è arrivata.
- Le unità non ancora visibili compaiono nell'indice con il lucchetto («in arrivo»).
- L'ultima unità visibile è «in corso» e si apre da sola; le precedenti sono «svolte».
- Le voci aperte negli ultimi 7 giorni hanno l'etichetta «nuovo».

## Pubblicazione (una volta sola)
Repository **pubblico** di nome `classi` → *Settings → Pages → Deploy from a branch → main / (root)*.
In `config.js` sostituisci `archivio: "../archivio/"` con `archivio: "https://NOMEUTENTE.github.io/archivio/"`.

> Nota: ciò che non è attivo è nascosto, non segreto. Chi conosce l'indirizzo dell'archivio può comunque vedere tutto.
