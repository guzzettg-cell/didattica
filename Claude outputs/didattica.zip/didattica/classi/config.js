// Impostazioni del sito delle classi. Modifica qui nomi delle classi e indirizzo dell'archivio.
window.CONFIG = {
  // Indirizzo dell'archivio dei materiali (con la barra finale).
  // Per provare sul computer, con le due cartelle una accanto all'altra: "../archivio/"
  // Online, sostituisci con l'indirizzo vero, ad es.: "https://NOMEUTENTE.github.io/archivio/"
  archivio: "../archivio/",

  titolo: "Le nostre lezioni",

  // Una riga per classe. "id" è il nome del file in percorsi/ (senza .js): non usare spazi.
  classi: [
    { id: "classe-1", nome: "Classe 1", materia: "Storia" },
    { id: "classe-2", nome: "Classe 2", materia: "Storia" },
    { id: "classe-3", nome: "Classe 3", materia: "Geografia" },
    { id: "classe-4", nome: "Classe 4", materia: "Italiano" }
  ],

  // Per quanti giorni una voce appena attivata mostra l'etichetta "nuovo"
  giorniNovita: 7
};
