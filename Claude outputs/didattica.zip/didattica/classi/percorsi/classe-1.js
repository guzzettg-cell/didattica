// Percorso della classe — ESEMPIO. Si può modificare con docente.html.
window.PERCORSO = {
 "classe": "classe-1",
 "unita": [
  {
   "titolo": "Il Seicento",
   "attiva": true,
   "dal": "",
   "voci": [
    {
     "file": "materiali/storia/seicento-idea-principale.html",
     "titolo": "Il Seicento — Idea principale",
     "tipo": "Lezione",
     "parti": ["dove", "quando", "chi"],
     "attiva": true,
     "dal": "2026-11-20",
     "nota": "Solo le tre parti principali, senza approfondimento"
    },
    {
     "file": "materiali/storia/seicento-rivoluzione-scientifica.html",
     "titolo": "La rivoluzione scientifica — Esercizi",
     "tipo": "Esercizi",
     "parti": ["base"],
     "attiva": true,
     "dal": "",
     "nota": ""
    },
    {
     "titolo": "Libro: pagine 112–115, leggere e sottolineare",
     "tipo": "Compito",
     "attiva": false,
     "dal": "2026-12-01",
     "nota": "Si attiva da sola il 1° dicembre"
    }
   ]
  },
  {
   "titolo": "Il Settecento e l'Illuminismo",
   "attiva": false,
   "dal": "",
   "voci": []
  }
 ]
};
